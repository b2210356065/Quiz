import sys
d =[]

def g(f):
    f = int(f)
    if not f<=0:
        d.append(2*f-1)
        return g(f-1)
g(sys.argv[1])

z = len(d)-1
for i in range(len(d)):
    print(" "*(z)+"*"*int(d[z]))
    z-=1
k = 1-len(d)
for i in range(0,len(d)-1):
    print(" "*int(len(d)+k)+"*"*int(d[k]))
    k+=1


