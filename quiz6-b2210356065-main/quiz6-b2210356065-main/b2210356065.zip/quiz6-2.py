import sys
def c(a):
    d=[2*i-1 for i in range(1,int(a)+1) if i>0]
    z = 0 - len(d)
    for i in range(len(d)):
        print(" "*(-z)+"*"*int(d[z]))
        z+=1
    k = len(d)-2
    for i in range(0,len(d)-1):
        print(" "*int(len(d)-k)+"*"*int(d[k]))
        k-=1

c(sys.argv[1])